
from django.urls import path,include
from . import views
from .pdf import appointmentPdf
urlpatterns = [
   
    path("",views.index, name="index"),
    path("appointment", views.appointment, name="appointment"),
    path("confirm", views.confirm, name="confirm"),
     path("pdf", appointmentPdf, name="pdf")
]
