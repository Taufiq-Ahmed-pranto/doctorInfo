from io import BytesIO
from django.shortcuts import render
from django.template.loader import get_template
from django.http import HttpResponse
from xhtml2pdf import pisa
from .models import Appointment

def renderToPdf(template_src, context_dictionary):
    template = get_template(template_src)
    html = template.render(context_dictionary)
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)

    if not pdf.err:
        return HttpResponse(result.getvalue(), content_type="application/pdf")
    
    return None


def appointmentPdf(request):
    if request.method == "POST":
        patient = request.POST.get("patient")
        date = request.POST.get("doctorDate")
        appointment = Appointment.objects.filter(patientName=patient, date=date)
        context={
            'appointment':appointment,
        }
        pdf = renderToPdf('appointmentPdf.html', context)
        if pdf:
            response = HttpResponse(pdf, content_type="application/pdf")
            content ="inline: filename=appointment.pdf"
            response['Content-Disposition']=content
            return response
        return HttpResponse("not found")
    
    return render(request, "/")

