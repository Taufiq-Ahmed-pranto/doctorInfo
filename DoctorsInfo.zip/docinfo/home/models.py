from django.db import models

# Create your models here.
class Doctor(models.Model):
    name = models.CharField(max_length=200)
    category = models.CharField(max_length=200)
    location = models.CharField(max_length=200)
    worksDay = models.CharField(max_length=200)
    charge = models.IntegerField()
    image = models.ImageField(upload_to="static/doctorImage")

    def __str__(self):
        return self.name


class Appointment(models.Model):
    patientName = models.CharField(max_length=200)
    patientPhone = models.CharField(max_length=200)
    date = models.CharField(max_length=200)
    doctorName = models.CharField(max_length=200)
    doctorLocation = models.CharField(max_length=200)
    doctorCharge = models.IntegerField()
    doctorCategory = models.CharField(max_length=200)
    username = models.CharField(max_length=200, default="")

    def __str__(self):
        return self.patientName
    
   