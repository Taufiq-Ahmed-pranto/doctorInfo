from django.shortcuts import render, redirect
from .models import Doctor, Appointment
from django.contrib.auth.models import User, auth
from datetime import datetime
from django.contrib import messages
# Create your views here.



def index(request):
    doctors = Doctor.objects.all()
    if request.method == "POST":
        location = request.POST.get("location")
        category = request.POST.get("category")
        doctors = Doctor.objects.filter(location=location, category=category)
    return render(request, "index.html", {'doctors': doctors})


def appointment(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            name = request.POST.get("doctorName")
            doctor = Doctor.objects.filter(name=name)
            return render(request, 'appointment.html', {'doctor': doctor})

    else:
        return redirect("accounts/signin")


def confirm(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            patient = request.POST.get("patient")
            doctor = request.POST.get("doctorName")
            phone = request.POST.get("phone")
            date = request.POST.get("date")
            category = request.POST.get("category")
            location = request.POST.get("location")
            charge = request.POST.get("charge")
            username = request.POST.get("username")
            #check doctors date is valid
            doctorDetail = Doctor.objects.filter(name=doctor)
            worksday = str(doctorDetail[0].worksDay)
            print(worksday)
            dateObj = datetime.strptime(date, '%Y-%m-%d')
            inputday = str(dateObj.strftime('%A'))
            print(inputday)
            if(inputday in worksday):
                print("True")
                appointment = Appointment(patientName=patient, doctorName=doctor,
                                          patientPhone=phone, date=date, doctorCategory=category,
                                          doctorLocation=location, doctorCharge=charge, username=username)
                appointment.save()
                return render(request, 'confirm.html', {'appointment': appointment})
            else:
                messages.info(request, "doctor's will not available")
                return render(request, 'appointment.html', {'doctor': doctorDetail})
    else:
        redirect("accounts/signin")
