from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
from home.models import Appointment

# Create your views here.
def signout(request):
    auth.logout(request)
    return redirect("/")

def signin(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")
        user = auth.authenticate(username=username, email= email, password=password)
        if user is not None:
            auth.login(request, user)
            print("sign in success")
            return redirect("/")
        else:
            print("come here")
            messages.info(request, 'invalid credentials')
            return redirect("signin")
    else:
        return render(request,"signin.html")


def signup(request):
    if request.method=="POST":
        firstName = request.POST.get("first_name")
        lastName = request.POST.get("last_name")
        userName = request.POST.get("username")
        email = request.POST.get("email")
        password1 = request.POST.get("password1")
        password2 = request.POST.get("password2")
        
        if password1==password2:
            if User.objects.filter(username=userName).exists():
                messages.info(request, 'username taken')
                return redirect("signup")
            
            elif User.objects.filter(email=email).exists():
                 print("email taken")
                 messages.info(request, 'email taken')
                 return redirect("signup")

            else:
                user = User.objects.create_user(username=userName, password=password1, email=email,
                first_name =firstName, last_name = lastName)
                user.save()
                return redirect("signin")

        else:
            print("password is not matching")
            messages.info(request, 'password not matching')
            return redirect("signup")  
    else:
        return render(request, 'signup.html')



def profile(request):
    username = request.user.username
    appointment = Appointment.objects.filter(username=username)
    return render(request, 'profile.html',{'appointments':appointment})